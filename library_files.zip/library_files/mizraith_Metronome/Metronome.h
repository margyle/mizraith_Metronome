/**
 * PART OF mizraith_Metronome package
 *
 * This file specs the strings and constants and lookup tables
 * used by the metronome.   A good chunk is programatically 
 * generated using a python script.  
 *
 * We try to load as much into PROGMEM as possible in order ot
 * save our limited Arduino RAM.  
 *
 * Author:  Red Byer       github.com/mizraith
 * Date:    4/2013
 * License:  Free to use & deploy however, but you must include author
 *           and source link information citation.
 *           No warranty implied. Enjoy!
 *
 *
 */
 
#ifndef _mizraith_Metronome_H_
#define _mizraith_Metronome_H_

#include <Arduino.h>
//#include "Metronome_Data.h"

const prog_char Blank_16String[]              PROGMEM =  {"                "};
const prog_char CalicoString[]                PROGMEM =  {"CALICO MUSIC    "};
const prog_char MetronomeString[]             PROGMEM =  {"METRONOME  v1.0 "};


//#############################################
// TEMPOS
//   up to in BPM
//#############################################
                          //up to in BPM, with some interpretation to fill it out, see Wikipedia
                          //        idx   Italian term
const uint8_t LIST_OF_TEMPOS[] = { 
                           19,      //0  Larghissimo
                           40,      //1  Grave
                           45,      //2  Lento
                           50,      //3  Largo
                           55,      //4  Larghetto
                           65,      //5  Adagio
                           70,      //6  Adagietto
                           80,      //7  Andantino
                           85,      //8  Marcia Moderato  
                           90,      //9  Andante
                           100,     //10 Andante Moderato
                           112,     //11 Moderato
                           116,     //12  Allegro Moderato
                           120,     //13  Allegretto
                           140,     //14  Allegro
                           150,     //15  Vivace
                           165,     //16  Vivacissimo
                           180,     //17  Allegrissimo
                           200,     //18  Presto
                           240,     //19  Prestissimo
                           242,     //10  Rapido
                           255,     //21  Plaid
                           };
    
const uint8_t TEMPO_LIST_LENGTH = 22;
                           
const prog_char s00[]  PROGMEM = {"Larghissimo"};
const prog_char s01[]  PROGMEM = {"Grave"};
const prog_char s02[]  PROGMEM = {"Lento"};
const prog_char s03[]  PROGMEM = {"Largo"};
const prog_char s04[]  PROGMEM = {"Larghetto"};
const prog_char s05[]  PROGMEM = {"Adagio"};
const prog_char s06[]  PROGMEM = {"Adagietto"};
const prog_char s07[]  PROGMEM = {"Andantino"};
const prog_char s08[]  PROGMEM = {"Marcia Moderato"};
const prog_char s09[]  PROGMEM = {"Andante"};
const prog_char s10[]  PROGMEM = {"Andante Moderato"};
const prog_char s11[]  PROGMEM = {"Moderato"};
const prog_char s12[]  PROGMEM = {"Allegro Moderato"};
const prog_char s13[]  PROGMEM = {"Allegretto"};
const prog_char s14[]  PROGMEM = {"Allegro"};
const prog_char s15[]  PROGMEM = {"Vivace"};
const prog_char s16[]  PROGMEM = {"Vivacissimo"};
const prog_char s17[]  PROGMEM = {"Allegrissimo"};
const prog_char s18[]  PROGMEM = {"Presto"};
const prog_char s19[]  PROGMEM = {"Prestissimo"};
const prog_char s20[]  PROGMEM = {"Rapido"};
const prog_char s21[]  PROGMEM = {"Plaid"};

PROGMEM const prog_char * LIST_OF_TEMPO_NAMES[] = {
                                            s00, s01, s02, s03, s04, s05, s06, s07, s08, s09,
                                            s10, s11, s12, s13, s14, s15, s16, s17, s18, s19, 
                                            s20, s21 
                                            };                           


// ###########################################################################
//  ALL THE TEXT UP TO THE #endif BELOW IS PROGRAMATICALLY GENERATED
// ###########################################################################


// LCD Backlight Table, based on BPMs
// Generated via BPM_Colormap.py script...easier to edit that

/* Structure for defining a color */
struct color_24bits  {
                    uint8_t         red_value;     
                    uint8_t         green_value;
                    uint8_t         blue_value;
                    };



const struct color_24bits bpmcolor0 PROGMEM = { 0, 0, 0 };
const struct color_24bits bpmcolor1 PROGMEM = { 4, 0, 0 };
const struct color_24bits bpmcolor2 PROGMEM = { 8, 0, 0 };
const struct color_24bits bpmcolor3 PROGMEM = { 12, 0, 0 };
const struct color_24bits bpmcolor4 PROGMEM = { 16, 0, 0 };
const struct color_24bits bpmcolor5 PROGMEM = { 20, 0, 0 };
const struct color_24bits bpmcolor6 PROGMEM = { 24, 0, 0 };
const struct color_24bits bpmcolor7 PROGMEM = { 28, 0, 0 };
const struct color_24bits bpmcolor8 PROGMEM = { 32, 0, 0 };
const struct color_24bits bpmcolor9 PROGMEM = { 36, 0, 0 };
const struct color_24bits bpmcolor10 PROGMEM = { 40, 0, 0 };
const struct color_24bits bpmcolor11 PROGMEM = { 44, 0, 0 };
const struct color_24bits bpmcolor12 PROGMEM = { 48, 0, 0 };
const struct color_24bits bpmcolor13 PROGMEM = { 52, 0, 0 };
const struct color_24bits bpmcolor14 PROGMEM = { 56, 0, 0 };
const struct color_24bits bpmcolor15 PROGMEM = { 60, 0, 0 };
const struct color_24bits bpmcolor16 PROGMEM = { 64, 0, 0 };
const struct color_24bits bpmcolor17 PROGMEM = { 68, 0, 0 };
const struct color_24bits bpmcolor18 PROGMEM = { 72, 0, 0 };
const struct color_24bits bpmcolor19 PROGMEM = { 76, 0, 0 };
const struct color_24bits bpmcolor20 PROGMEM = { 80, 0, 0 };
const struct color_24bits bpmcolor21 PROGMEM = { 84, 0, 0 };
const struct color_24bits bpmcolor22 PROGMEM = { 88, 0, 0 };
const struct color_24bits bpmcolor23 PROGMEM = { 92, 0, 0 };
const struct color_24bits bpmcolor24 PROGMEM = { 96, 0, 0 };
const struct color_24bits bpmcolor25 PROGMEM = { 100, 0, 0 };
const struct color_24bits bpmcolor26 PROGMEM = { 104, 0, 0 };
const struct color_24bits bpmcolor27 PROGMEM = { 108, 0, 0 };
const struct color_24bits bpmcolor28 PROGMEM = { 112, 0, 0 };
const struct color_24bits bpmcolor29 PROGMEM = { 116, 0, 0 };
const struct color_24bits bpmcolor30 PROGMEM = { 120, 0, 0 };
const struct color_24bits bpmcolor31 PROGMEM = { 124, 0, 0 };
const struct color_24bits bpmcolor32 PROGMEM = { 128, 0, 0 };
const struct color_24bits bpmcolor33 PROGMEM = { 132, 0, 0 };
const struct color_24bits bpmcolor34 PROGMEM = { 136, 0, 0 };
const struct color_24bits bpmcolor35 PROGMEM = { 140, 0, 0 };
const struct color_24bits bpmcolor36 PROGMEM = { 144, 0, 0 };
const struct color_24bits bpmcolor37 PROGMEM = { 148, 0, 0 };
const struct color_24bits bpmcolor38 PROGMEM = { 152, 0, 0 };
const struct color_24bits bpmcolor39 PROGMEM = { 156, 0, 0 };
const struct color_24bits bpmcolor40 PROGMEM = { 160, 0, 0 };
const struct color_24bits bpmcolor41 PROGMEM = { 164, 0, 0 };
const struct color_24bits bpmcolor42 PROGMEM = { 168, 0, 0 };
const struct color_24bits bpmcolor43 PROGMEM = { 172, 0, 0 };
const struct color_24bits bpmcolor44 PROGMEM = { 176, 0, 0 };
const struct color_24bits bpmcolor45 PROGMEM = { 180, 0, 0 };
const struct color_24bits bpmcolor46 PROGMEM = { 184, 0, 0 };
const struct color_24bits bpmcolor47 PROGMEM = { 188, 0, 0 };
const struct color_24bits bpmcolor48 PROGMEM = { 192, 0, 0 };
const struct color_24bits bpmcolor49 PROGMEM = { 196, 0, 0 };
const struct color_24bits bpmcolor50 PROGMEM = { 200, 0, 0 };
const struct color_24bits bpmcolor51 PROGMEM = { 204, 0, 0 };
const struct color_24bits bpmcolor52 PROGMEM = { 208, 0, 0 };
const struct color_24bits bpmcolor53 PROGMEM = { 212, 0, 0 };
const struct color_24bits bpmcolor54 PROGMEM = { 216, 0, 0 };
const struct color_24bits bpmcolor55 PROGMEM = { 220, 0, 0 };
const struct color_24bits bpmcolor56 PROGMEM = { 224, 0, 0 };
const struct color_24bits bpmcolor57 PROGMEM = { 228, 0, 0 };
const struct color_24bits bpmcolor58 PROGMEM = { 232, 0, 0 };
const struct color_24bits bpmcolor59 PROGMEM = { 236, 0, 0 };
const struct color_24bits bpmcolor60 PROGMEM = { 240, 0, 0 };
const struct color_24bits bpmcolor61 PROGMEM = { 236, 4, 0 };
const struct color_24bits bpmcolor62 PROGMEM = { 232, 8, 0 };
const struct color_24bits bpmcolor63 PROGMEM = { 228, 12, 0 };
const struct color_24bits bpmcolor64 PROGMEM = { 224, 16, 0 };
const struct color_24bits bpmcolor65 PROGMEM = { 220, 20, 0 };
const struct color_24bits bpmcolor66 PROGMEM = { 216, 24, 0 };
const struct color_24bits bpmcolor67 PROGMEM = { 212, 28, 0 };
const struct color_24bits bpmcolor68 PROGMEM = { 208, 32, 0 };
const struct color_24bits bpmcolor69 PROGMEM = { 204, 36, 0 };
const struct color_24bits bpmcolor70 PROGMEM = { 200, 40, 0 };
const struct color_24bits bpmcolor71 PROGMEM = { 196, 44, 0 };
const struct color_24bits bpmcolor72 PROGMEM = { 192, 48, 0 };
const struct color_24bits bpmcolor73 PROGMEM = { 188, 52, 0 };
const struct color_24bits bpmcolor74 PROGMEM = { 184, 56, 0 };
const struct color_24bits bpmcolor75 PROGMEM = { 180, 60, 0 };
const struct color_24bits bpmcolor76 PROGMEM = { 176, 64, 0 };
const struct color_24bits bpmcolor77 PROGMEM = { 172, 68, 0 };
const struct color_24bits bpmcolor78 PROGMEM = { 168, 72, 0 };
const struct color_24bits bpmcolor79 PROGMEM = { 164, 76, 0 };
const struct color_24bits bpmcolor80 PROGMEM = { 160, 80, 0 };
const struct color_24bits bpmcolor81 PROGMEM = { 156, 84, 0 };
const struct color_24bits bpmcolor82 PROGMEM = { 152, 88, 0 };
const struct color_24bits bpmcolor83 PROGMEM = { 148, 92, 0 };
const struct color_24bits bpmcolor84 PROGMEM = { 144, 96, 0 };
const struct color_24bits bpmcolor85 PROGMEM = { 140, 100, 0 };
const struct color_24bits bpmcolor86 PROGMEM = { 136, 104, 0 };
const struct color_24bits bpmcolor87 PROGMEM = { 132, 108, 0 };
const struct color_24bits bpmcolor88 PROGMEM = { 128, 112, 0 };
const struct color_24bits bpmcolor89 PROGMEM = { 124, 116, 0 };
const struct color_24bits bpmcolor90 PROGMEM = { 120, 120, 0 };
const struct color_24bits bpmcolor91 PROGMEM = { 116, 124, 0 };
const struct color_24bits bpmcolor92 PROGMEM = { 112, 128, 0 };
const struct color_24bits bpmcolor93 PROGMEM = { 108, 132, 0 };
const struct color_24bits bpmcolor94 PROGMEM = { 104, 136, 0 };
const struct color_24bits bpmcolor95 PROGMEM = { 100, 140, 0 };
const struct color_24bits bpmcolor96 PROGMEM = { 96, 144, 0 };
const struct color_24bits bpmcolor97 PROGMEM = { 92, 148, 0 };
const struct color_24bits bpmcolor98 PROGMEM = { 88, 152, 0 };
const struct color_24bits bpmcolor99 PROGMEM = { 84, 156, 0 };
const struct color_24bits bpmcolor100 PROGMEM = { 80, 160, 0 };
const struct color_24bits bpmcolor101 PROGMEM = { 76, 164, 0 };
const struct color_24bits bpmcolor102 PROGMEM = { 72, 168, 0 };
const struct color_24bits bpmcolor103 PROGMEM = { 68, 172, 0 };
const struct color_24bits bpmcolor104 PROGMEM = { 64, 176, 0 };
const struct color_24bits bpmcolor105 PROGMEM = { 60, 180, 0 };
const struct color_24bits bpmcolor106 PROGMEM = { 56, 184, 0 };
const struct color_24bits bpmcolor107 PROGMEM = { 52, 188, 0 };
const struct color_24bits bpmcolor108 PROGMEM = { 48, 192, 0 };
const struct color_24bits bpmcolor109 PROGMEM = { 44, 196, 0 };
const struct color_24bits bpmcolor110 PROGMEM = { 40, 200, 0 };
const struct color_24bits bpmcolor111 PROGMEM = { 36, 204, 0 };
const struct color_24bits bpmcolor112 PROGMEM = { 32, 208, 0 };
const struct color_24bits bpmcolor113 PROGMEM = { 28, 212, 0 };
const struct color_24bits bpmcolor114 PROGMEM = { 24, 216, 0 };
const struct color_24bits bpmcolor115 PROGMEM = { 20, 220, 0 };
const struct color_24bits bpmcolor116 PROGMEM = { 16, 224, 0 };
const struct color_24bits bpmcolor117 PROGMEM = { 12, 228, 0 };
const struct color_24bits bpmcolor118 PROGMEM = { 8, 232, 0 };
const struct color_24bits bpmcolor119 PROGMEM = { 4, 236, 0 };
const struct color_24bits bpmcolor120 PROGMEM = { 0, 240, 0 };
const struct color_24bits bpmcolor121 PROGMEM = { 0, 236, 4 };
const struct color_24bits bpmcolor122 PROGMEM = { 0, 232, 8 };
const struct color_24bits bpmcolor123 PROGMEM = { 0, 228, 12 };
const struct color_24bits bpmcolor124 PROGMEM = { 0, 224, 16 };
const struct color_24bits bpmcolor125 PROGMEM = { 0, 220, 20 };
const struct color_24bits bpmcolor126 PROGMEM = { 0, 216, 24 };
const struct color_24bits bpmcolor127 PROGMEM = { 0, 212, 28 };
const struct color_24bits bpmcolor128 PROGMEM = { 0, 208, 32 };
const struct color_24bits bpmcolor129 PROGMEM = { 0, 204, 36 };
const struct color_24bits bpmcolor130 PROGMEM = { 0, 200, 40 };
const struct color_24bits bpmcolor131 PROGMEM = { 0, 196, 44 };
const struct color_24bits bpmcolor132 PROGMEM = { 0, 192, 48 };
const struct color_24bits bpmcolor133 PROGMEM = { 0, 188, 52 };
const struct color_24bits bpmcolor134 PROGMEM = { 0, 184, 56 };
const struct color_24bits bpmcolor135 PROGMEM = { 0, 180, 60 };
const struct color_24bits bpmcolor136 PROGMEM = { 0, 176, 64 };
const struct color_24bits bpmcolor137 PROGMEM = { 0, 172, 68 };
const struct color_24bits bpmcolor138 PROGMEM = { 0, 168, 72 };
const struct color_24bits bpmcolor139 PROGMEM = { 0, 164, 76 };
const struct color_24bits bpmcolor140 PROGMEM = { 0, 160, 80 };
const struct color_24bits bpmcolor141 PROGMEM = { 0, 156, 84 };
const struct color_24bits bpmcolor142 PROGMEM = { 0, 152, 88 };
const struct color_24bits bpmcolor143 PROGMEM = { 0, 148, 92 };
const struct color_24bits bpmcolor144 PROGMEM = { 0, 144, 96 };
const struct color_24bits bpmcolor145 PROGMEM = { 0, 140, 100 };
const struct color_24bits bpmcolor146 PROGMEM = { 0, 136, 104 };
const struct color_24bits bpmcolor147 PROGMEM = { 0, 132, 108 };
const struct color_24bits bpmcolor148 PROGMEM = { 0, 128, 112 };
const struct color_24bits bpmcolor149 PROGMEM = { 0, 124, 116 };
const struct color_24bits bpmcolor150 PROGMEM = { 0, 120, 120 };
const struct color_24bits bpmcolor151 PROGMEM = { 0, 116, 124 };
const struct color_24bits bpmcolor152 PROGMEM = { 0, 112, 128 };
const struct color_24bits bpmcolor153 PROGMEM = { 0, 108, 132 };
const struct color_24bits bpmcolor154 PROGMEM = { 0, 104, 136 };
const struct color_24bits bpmcolor155 PROGMEM = { 0, 100, 140 };
const struct color_24bits bpmcolor156 PROGMEM = { 0, 96, 144 };
const struct color_24bits bpmcolor157 PROGMEM = { 0, 92, 148 };
const struct color_24bits bpmcolor158 PROGMEM = { 0, 88, 152 };
const struct color_24bits bpmcolor159 PROGMEM = { 0, 84, 156 };
const struct color_24bits bpmcolor160 PROGMEM = { 0, 80, 160 };
const struct color_24bits bpmcolor161 PROGMEM = { 0, 76, 164 };
const struct color_24bits bpmcolor162 PROGMEM = { 0, 72, 168 };
const struct color_24bits bpmcolor163 PROGMEM = { 0, 68, 172 };
const struct color_24bits bpmcolor164 PROGMEM = { 0, 64, 176 };
const struct color_24bits bpmcolor165 PROGMEM = { 0, 60, 180 };
const struct color_24bits bpmcolor166 PROGMEM = { 0, 56, 184 };
const struct color_24bits bpmcolor167 PROGMEM = { 0, 52, 188 };
const struct color_24bits bpmcolor168 PROGMEM = { 0, 48, 192 };
const struct color_24bits bpmcolor169 PROGMEM = { 0, 44, 196 };
const struct color_24bits bpmcolor170 PROGMEM = { 0, 40, 200 };
const struct color_24bits bpmcolor171 PROGMEM = { 0, 36, 204 };
const struct color_24bits bpmcolor172 PROGMEM = { 0, 32, 208 };
const struct color_24bits bpmcolor173 PROGMEM = { 0, 28, 212 };
const struct color_24bits bpmcolor174 PROGMEM = { 0, 24, 216 };
const struct color_24bits bpmcolor175 PROGMEM = { 0, 20, 220 };
const struct color_24bits bpmcolor176 PROGMEM = { 0, 16, 224 };
const struct color_24bits bpmcolor177 PROGMEM = { 0, 12, 228 };
const struct color_24bits bpmcolor178 PROGMEM = { 0, 8, 232 };
const struct color_24bits bpmcolor179 PROGMEM = { 0, 4, 236 };
const struct color_24bits bpmcolor180 PROGMEM = { 0, 0, 240 };
const struct color_24bits bpmcolor181 PROGMEM = { 4, 0, 240 };
const struct color_24bits bpmcolor182 PROGMEM = { 8, 0, 240 };
const struct color_24bits bpmcolor183 PROGMEM = { 12, 0, 240 };
const struct color_24bits bpmcolor184 PROGMEM = { 16, 0, 240 };
const struct color_24bits bpmcolor185 PROGMEM = { 20, 0, 240 };
const struct color_24bits bpmcolor186 PROGMEM = { 24, 0, 240 };
const struct color_24bits bpmcolor187 PROGMEM = { 28, 0, 240 };
const struct color_24bits bpmcolor188 PROGMEM = { 32, 0, 240 };
const struct color_24bits bpmcolor189 PROGMEM = { 36, 0, 240 };
const struct color_24bits bpmcolor190 PROGMEM = { 40, 0, 240 };
const struct color_24bits bpmcolor191 PROGMEM = { 44, 0, 240 };
const struct color_24bits bpmcolor192 PROGMEM = { 48, 0, 240 };
const struct color_24bits bpmcolor193 PROGMEM = { 52, 0, 240 };
const struct color_24bits bpmcolor194 PROGMEM = { 56, 0, 240 };
const struct color_24bits bpmcolor195 PROGMEM = { 60, 0, 240 };
const struct color_24bits bpmcolor196 PROGMEM = { 64, 0, 240 };
const struct color_24bits bpmcolor197 PROGMEM = { 68, 0, 240 };
const struct color_24bits bpmcolor198 PROGMEM = { 72, 0, 240 };
const struct color_24bits bpmcolor199 PROGMEM = { 76, 0, 240 };
const struct color_24bits bpmcolor200 PROGMEM = { 80, 0, 240 };
const struct color_24bits bpmcolor201 PROGMEM = { 84, 0, 240 };
const struct color_24bits bpmcolor202 PROGMEM = { 88, 0, 240 };
const struct color_24bits bpmcolor203 PROGMEM = { 92, 0, 240 };
const struct color_24bits bpmcolor204 PROGMEM = { 96, 0, 240 };
const struct color_24bits bpmcolor205 PROGMEM = { 100, 0, 240 };
const struct color_24bits bpmcolor206 PROGMEM = { 104, 0, 240 };
const struct color_24bits bpmcolor207 PROGMEM = { 108, 0, 240 };
const struct color_24bits bpmcolor208 PROGMEM = { 112, 0, 240 };
const struct color_24bits bpmcolor209 PROGMEM = { 116, 0, 240 };
const struct color_24bits bpmcolor210 PROGMEM = { 120, 0, 240 };
const struct color_24bits bpmcolor211 PROGMEM = { 124, 0, 240 };
const struct color_24bits bpmcolor212 PROGMEM = { 128, 0, 240 };
const struct color_24bits bpmcolor213 PROGMEM = { 132, 0, 240 };
const struct color_24bits bpmcolor214 PROGMEM = { 136, 0, 240 };
const struct color_24bits bpmcolor215 PROGMEM = { 140, 0, 240 };
const struct color_24bits bpmcolor216 PROGMEM = { 144, 0, 240 };
const struct color_24bits bpmcolor217 PROGMEM = { 148, 0, 240 };
const struct color_24bits bpmcolor218 PROGMEM = { 152, 0, 240 };
const struct color_24bits bpmcolor219 PROGMEM = { 156, 0, 240 };
const struct color_24bits bpmcolor220 PROGMEM = { 160, 0, 240 };
const struct color_24bits bpmcolor221 PROGMEM = { 164, 0, 240 };
const struct color_24bits bpmcolor222 PROGMEM = { 168, 0, 240 };
const struct color_24bits bpmcolor223 PROGMEM = { 172, 0, 240 };
const struct color_24bits bpmcolor224 PROGMEM = { 176, 0, 240 };
const struct color_24bits bpmcolor225 PROGMEM = { 180, 0, 240 };
const struct color_24bits bpmcolor226 PROGMEM = { 184, 0, 240 };
const struct color_24bits bpmcolor227 PROGMEM = { 188, 0, 240 };
const struct color_24bits bpmcolor228 PROGMEM = { 192, 0, 240 };
const struct color_24bits bpmcolor229 PROGMEM = { 196, 0, 240 };
const struct color_24bits bpmcolor230 PROGMEM = { 200, 0, 240 };
const struct color_24bits bpmcolor231 PROGMEM = { 204, 0, 240 };
const struct color_24bits bpmcolor232 PROGMEM = { 208, 0, 240 };
const struct color_24bits bpmcolor233 PROGMEM = { 212, 0, 240 };
const struct color_24bits bpmcolor234 PROGMEM = { 216, 0, 240 };
const struct color_24bits bpmcolor235 PROGMEM = { 220, 0, 240 };
const struct color_24bits bpmcolor236 PROGMEM = { 224, 0, 240 };
const struct color_24bits bpmcolor237 PROGMEM = { 228, 0, 240 };
const struct color_24bits bpmcolor238 PROGMEM = { 232, 0, 240 };
const struct color_24bits bpmcolor239 PROGMEM = { 236, 0, 240 };
const struct color_24bits bpmcolor240 PROGMEM = { 240, 40, 240 };
const struct color_24bits bpmcolor241 PROGMEM = { 240, 80, 240 };
const struct color_24bits bpmcolor242 PROGMEM = { 240, 120, 240 };
const struct color_24bits bpmcolor243 PROGMEM = { 240, 160, 240 };
const struct color_24bits bpmcolor244 PROGMEM = { 240, 200, 240 };
const struct color_24bits bpmcolor245 PROGMEM = { 240, 240, 240 };
const struct color_24bits bpmcolor246 PROGMEM = { 255, 0, 0 };
const struct color_24bits bpmcolor247 PROGMEM = { 0, 0, 255 };
const struct color_24bits bpmcolor248 PROGMEM = { 0, 255, 0 };
const struct color_24bits bpmcolor249 PROGMEM = { 255, 255, 255 };
const struct color_24bits bpmcolor250 PROGMEM = { 255, 255, 0 };
const struct color_24bits bpmcolor251 PROGMEM = { 255, 0, 255 };
const struct color_24bits bpmcolor252 PROGMEM = { 150, 150, 150 };
const struct color_24bits bpmcolor253 PROGMEM = { 255, 0, 0 };
const struct color_24bits bpmcolor254 PROGMEM = { 0, 255, 0 };



PROGMEM const struct color_24bits * BPM_COLOR_LIST[] = { 
                                  &bpmcolor0, 
                                  &bpmcolor1, 
                                  &bpmcolor2, 
                                  &bpmcolor3, 
                                  &bpmcolor4, 
                                  &bpmcolor5, 
                                  &bpmcolor6, 
                                  &bpmcolor7, 
                                  &bpmcolor8, 
                                  &bpmcolor9, 
                                  &bpmcolor10, 
                                  &bpmcolor11, 
                                  &bpmcolor12, 
                                  &bpmcolor13, 
                                  &bpmcolor14, 
                                  &bpmcolor15, 
                                  &bpmcolor16, 
                                  &bpmcolor17, 
                                  &bpmcolor18, 
                                  &bpmcolor19, 
                                  &bpmcolor20, 
                                  &bpmcolor21, 
                                  &bpmcolor22, 
                                  &bpmcolor23, 
                                  &bpmcolor24, 
                                  &bpmcolor25, 
                                  &bpmcolor26, 
                                  &bpmcolor27, 
                                  &bpmcolor28, 
                                  &bpmcolor29, 
                                  &bpmcolor30, 
                                  &bpmcolor31, 
                                  &bpmcolor32, 
                                  &bpmcolor33, 
                                  &bpmcolor34, 
                                  &bpmcolor35, 
                                  &bpmcolor36, 
                                  &bpmcolor37, 
                                  &bpmcolor38, 
                                  &bpmcolor39, 
                                  &bpmcolor40, 
                                  &bpmcolor41, 
                                  &bpmcolor42, 
                                  &bpmcolor43, 
                                  &bpmcolor44, 
                                  &bpmcolor45, 
                                  &bpmcolor46, 
                                  &bpmcolor47, 
                                  &bpmcolor48, 
                                  &bpmcolor49, 
                                  &bpmcolor50, 
                                  &bpmcolor51, 
                                  &bpmcolor52, 
                                  &bpmcolor53, 
                                  &bpmcolor54, 
                                  &bpmcolor55, 
                                  &bpmcolor56, 
                                  &bpmcolor57, 
                                  &bpmcolor58, 
                                  &bpmcolor59, 
                                  &bpmcolor60, 
                                  &bpmcolor61, 
                                  &bpmcolor62, 
                                  &bpmcolor63, 
                                  &bpmcolor64, 
                                  &bpmcolor65, 
                                  &bpmcolor66, 
                                  &bpmcolor67, 
                                  &bpmcolor68, 
                                  &bpmcolor69, 
                                  &bpmcolor70, 
                                  &bpmcolor71, 
                                  &bpmcolor72, 
                                  &bpmcolor73, 
                                  &bpmcolor74, 
                                  &bpmcolor75, 
                                  &bpmcolor76, 
                                  &bpmcolor77, 
                                  &bpmcolor78, 
                                  &bpmcolor79, 
                                  &bpmcolor80, 
                                  &bpmcolor81, 
                                  &bpmcolor82, 
                                  &bpmcolor83, 
                                  &bpmcolor84, 
                                  &bpmcolor85, 
                                  &bpmcolor86, 
                                  &bpmcolor87, 
                                  &bpmcolor88, 
                                  &bpmcolor89, 
                                  &bpmcolor90, 
                                  &bpmcolor91, 
                                  &bpmcolor92, 
                                  &bpmcolor93, 
                                  &bpmcolor94, 
                                  &bpmcolor95, 
                                  &bpmcolor96, 
                                  &bpmcolor97, 
                                  &bpmcolor98, 
                                  &bpmcolor99, 
                                  &bpmcolor100, 
                                  &bpmcolor101, 
                                  &bpmcolor102, 
                                  &bpmcolor103, 
                                  &bpmcolor104, 
                                  &bpmcolor105, 
                                  &bpmcolor106, 
                                  &bpmcolor107, 
                                  &bpmcolor108, 
                                  &bpmcolor109, 
                                  &bpmcolor110, 
                                  &bpmcolor111, 
                                  &bpmcolor112, 
                                  &bpmcolor113, 
                                  &bpmcolor114, 
                                  &bpmcolor115, 
                                  &bpmcolor116, 
                                  &bpmcolor117, 
                                  &bpmcolor118, 
                                  &bpmcolor119, 
                                  &bpmcolor120, 
                                  &bpmcolor121, 
                                  &bpmcolor122, 
                                  &bpmcolor123, 
                                  &bpmcolor124, 
                                  &bpmcolor125, 
                                  &bpmcolor126, 
                                  &bpmcolor127, 
                                  &bpmcolor128, 
                                  &bpmcolor129, 
                                  &bpmcolor130, 
                                  &bpmcolor131, 
                                  &bpmcolor132, 
                                  &bpmcolor133, 
                                  &bpmcolor134, 
                                  &bpmcolor135, 
                                  &bpmcolor136, 
                                  &bpmcolor137, 
                                  &bpmcolor138, 
                                  &bpmcolor139, 
                                  &bpmcolor140, 
                                  &bpmcolor141, 
                                  &bpmcolor142, 
                                  &bpmcolor143, 
                                  &bpmcolor144, 
                                  &bpmcolor145, 
                                  &bpmcolor146, 
                                  &bpmcolor147, 
                                  &bpmcolor148, 
                                  &bpmcolor149, 
                                  &bpmcolor150, 
                                  &bpmcolor151, 
                                  &bpmcolor152, 
                                  &bpmcolor153, 
                                  &bpmcolor154, 
                                  &bpmcolor155, 
                                  &bpmcolor156, 
                                  &bpmcolor157, 
                                  &bpmcolor158, 
                                  &bpmcolor159, 
                                  &bpmcolor160, 
                                  &bpmcolor161, 
                                  &bpmcolor162, 
                                  &bpmcolor163, 
                                  &bpmcolor164, 
                                  &bpmcolor165, 
                                  &bpmcolor166, 
                                  &bpmcolor167, 
                                  &bpmcolor168, 
                                  &bpmcolor169, 
                                  &bpmcolor170, 
                                  &bpmcolor171, 
                                  &bpmcolor172, 
                                  &bpmcolor173, 
                                  &bpmcolor174, 
                                  &bpmcolor175, 
                                  &bpmcolor176, 
                                  &bpmcolor177, 
                                  &bpmcolor178, 
                                  &bpmcolor179, 
                                  &bpmcolor180, 
                                  &bpmcolor181, 
                                  &bpmcolor182, 
                                  &bpmcolor183, 
                                  &bpmcolor184, 
                                  &bpmcolor185, 
                                  &bpmcolor186, 
                                  &bpmcolor187, 
                                  &bpmcolor188, 
                                  &bpmcolor189, 
                                  &bpmcolor190, 
                                  &bpmcolor191, 
                                  &bpmcolor192, 
                                  &bpmcolor193, 
                                  &bpmcolor194, 
                                  &bpmcolor195, 
                                  &bpmcolor196, 
                                  &bpmcolor197, 
                                  &bpmcolor198, 
                                  &bpmcolor199, 
                                  &bpmcolor200, 
                                  &bpmcolor201, 
                                  &bpmcolor202, 
                                  &bpmcolor203, 
                                  &bpmcolor204, 
                                  &bpmcolor205, 
                                  &bpmcolor206, 
                                  &bpmcolor207, 
                                  &bpmcolor208, 
                                  &bpmcolor209, 
                                  &bpmcolor210, 
                                  &bpmcolor211, 
                                  &bpmcolor212, 
                                  &bpmcolor213, 
                                  &bpmcolor214, 
                                  &bpmcolor215, 
                                  &bpmcolor216, 
                                  &bpmcolor217, 
                                  &bpmcolor218, 
                                  &bpmcolor219, 
                                  &bpmcolor220, 
                                  &bpmcolor221, 
                                  &bpmcolor222, 
                                  &bpmcolor223, 
                                  &bpmcolor224, 
                                  &bpmcolor225, 
                                  &bpmcolor226, 
                                  &bpmcolor227, 
                                  &bpmcolor228, 
                                  &bpmcolor229, 
                                  &bpmcolor230, 
                                  &bpmcolor231, 
                                  &bpmcolor232, 
                                  &bpmcolor233, 
                                  &bpmcolor234, 
                                  &bpmcolor235, 
                                  &bpmcolor236, 
                                  &bpmcolor237, 
                                  &bpmcolor238, 
                                  &bpmcolor239, 
                                  &bpmcolor240, 
                                  &bpmcolor241, 
                                  &bpmcolor242, 
                                  &bpmcolor243, 
                                  &bpmcolor244, 
                                  &bpmcolor245, 
                                  &bpmcolor246, 
                                  &bpmcolor247, 
                                  &bpmcolor248, 
                                  &bpmcolor249, 
                                  &bpmcolor250, 
                                  &bpmcolor251, 
                                  &bpmcolor252, 
                                  &bpmcolor253, 
                                  &bpmcolor254, 
                                 };



// ###########################################################################
//  ALL THE TEXT ABOVE IS PROGRAMATICALLY GENERATED
// ###########################################################################



#endif